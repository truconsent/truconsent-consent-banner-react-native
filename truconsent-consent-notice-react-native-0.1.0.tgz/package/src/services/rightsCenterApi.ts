/**
 * Rights Center API Service
 * Handles all API calls for the Rights Center feature
 */

export interface ConsentGroup {
  collection_point: string;
  title: string;
  purposes: Purpose[];
  data_elements?: DataElement[];
  shown_to_principal?: boolean;
}

export interface Purpose {
  id: string;
  name: string;
  description: string;
  expiry_period: string;
  is_mandatory: boolean;
  consented: 'accepted' | 'declined' | 'pending';
}

export interface DataElement {
  name: string;
  description: string;
}

export interface DPOInfo {
  full_name?: string;
  email?: string;
  appointment_date?: string;
  qualifications?: string;
  responsibilities?: string;
}

export interface Nominee {
  id?: string;
  nominee_name: string;
  relationship: string;
  nominee_email: string;
  nominee_mobile: string;
  purpose_of_appointment?: string;
  user_id?: string;
}

export interface GrievanceTicket {
  id?: string;
  subject: string;
  category: string;
  description: string;
  status?: string;
  created_at?: string;
  client_user_id?: string;
}

export interface RightsCenterSettings {
  background_color?: string;
  primary_text_color?: string;
  secondary_text_color?: string;
  button_color?: string;
  button_text_color?: string;
  font_family?: string;

  show_consents_section?: boolean;
  show_rights_section?: boolean;
  show_nominees_section?: boolean;
  show_transparency_section?: boolean;
  show_dpo_section?: boolean;
  show_grievance_section?: boolean;

  grievance_mode?: string;
  grievance_external_url?: string;

  consents_section_title?: string;
  rights_section_title?: string;
  nominees_section_title?: string;
  transparency_description?: string;

  dpo_qualifications_enabled?: boolean;
  dpo_responsibilities_enabled?: boolean;
  dpo_working_hours_enabled?: boolean;
  dpo_response_time_enabled?: boolean;
}

export interface ConsentPayload {
  userId: string;
  purposes: Array<{
    id: string;
    name: string;
    consented: 'accepted' | 'declined';
  }>;
  action: 'approved' | 'revoked' | 'declined';
  assetId?: string;
  changedPurposes?: string[];
}

class RightsCenterApi {
  private baseUrl: string;
  // TruAPI root (used for `/api/v1/...`). If the legacy `apiBaseUrl` ends with `/banners`,
  // strip that suffix so we can call the real API domain.
  private apiRootUrl: string;
  private apiKey: string;
  private organizationId: string;

  constructor(baseUrl: string, apiKey: string, organizationId: string) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.apiRootUrl = this.baseUrl.replace(/\/banners\/?$/, '');
    this.apiKey = apiKey;
    this.organizationId = organizationId;
  }

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (this.apiKey) {
      headers['X-API-Key'] = this.apiKey;
    }
    if (this.organizationId) {
      headers['X-Org-Id'] = this.organizationId;
    }
    return headers;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    // Ensure baseUrl doesn't end with / and endpoint starts with /
    const cleanBaseUrl = this.baseUrl.replace(/\/$/, '');
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    const url = `${cleanBaseUrl}${cleanEndpoint}`;
    const headers = { ...this.getHeaders(), ...(options.headers || {}) };

    try {
      console.log('[RightsCenterApi] Request:', url);
      console.log('[RightsCenterApi] Headers:', Object.keys(headers).join(', '));
      console.log('[RightsCenterApi] Method:', options.method || 'GET');
      
      const response = await fetch(url, {
        ...options,
        headers,
      });

      console.log('[RightsCenterApi] Response status:', response.status);
      console.log('[RightsCenterApi] Response headers:', Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        const errorText = await response.text();
        // If it's a 404 for root endpoint, this is expected - don't log as error
        if (response.status === 404 && (endpoint === '/' || endpoint === '')) {
          console.log('[RightsCenterApi] Root endpoint (/) returned 404 (expected)');
          return [] as T;
        }
        // If it's a 404 for user endpoint, return empty array
        if (response.status === 404 && endpoint.includes('/user/')) {
          console.warn('[RightsCenterApi] 404 for user endpoint, returning empty array');
          return [] as T;
        }
        // For other errors, log and throw
        console.error('[RightsCenterApi] Error response:', errorText.substring(0, 200));
        throw new Error(
          `API Error ${response.status}: ${errorText.substring(0, 100) || response.statusText}`
        );
      }

      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const data = await response.json();
        console.log('[RightsCenterApi] Response data type:', Array.isArray(data) ? `Array(${data.length})` : 'Object');
        return data as T;
      } else {
        const text = await response.text();
        console.warn('[RightsCenterApi] Non-JSON response:', text.substring(0, 100));
        // Try to parse as JSON anyway
        try {
          return JSON.parse(text) as T;
        } catch {
          throw new Error('Invalid response format: expected JSON');
        }
      }
    } catch (error: any) {
      console.error('[RightsCenterApi] Request failed:', error);
      if (error.message && error.message.includes('API Error')) {
        throw error;
      }
      throw new Error(`Network error: ${error.message || 'Failed to fetch'}`);
    }
  }

  /**
   * TruAPI request helper (`/api/v1/...` routes).
   * Uses `apiRootUrl` derived from the legacy `apiBaseUrl`.
   */
  private async requestApi<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const cleanBaseUrl = this.apiRootUrl.replace(/\/$/, '');
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    const url = `${cleanBaseUrl}${cleanEndpoint}`;
    const headers = { ...this.getHeaders(), ...(options.headers || {}) };

    try {
      console.log('[RightsCenterApi] Request (api):', url);

      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const errorText = await response.text();
        // For list-like endpoints, 404 is expected occasionally.
        if (response.status === 404 && (endpoint.includes('/user/') || endpoint.includes('/banners'))) {
          return [] as T;
        }
        console.error('[RightsCenterApi] Error response (api):', errorText.substring(0, 200));
        throw new Error(
          `API Error ${response.status}: ${errorText.substring(0, 100) || response.statusText}`
        );
      }

      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        return (await response.json()) as T;
      }

      const text = await response.text();
      // Try to parse as JSON anyway.
      try {
        return JSON.parse(text) as T;
      } catch {
        throw new Error('Invalid response format: expected JSON');
      }
    } catch (error: any) {
      console.error('[RightsCenterApi] Request failed (api):', error);
      throw new Error(`Network error: ${error.message || 'Failed to fetch'}`);
    }
  }

  async getRightsCenterSettings(assetId?: string): Promise<RightsCenterSettings> {
    const assetQuery = assetId ? `?asset_id=${encodeURIComponent(assetId)}` : '';
    const payload = await this.requestApi<any>(
      `/api/v1/rights-center/settings/global${assetQuery}`
    );

    // TruAPI may wrap in `{ data: {...} }`
    const data = payload?.data && typeof payload.data === 'object' ? payload.data : payload;
    return data as RightsCenterSettings;
  }

  async createAccessRequest(userId: string, assetId?: string): Promise<void> {
    await this.requestApi('/api/v1/rights-requests/access-request', {
      method: 'POST',
      body: JSON.stringify({
        user_id: userId,
        status: 'pending',
        subject: 'Data Access Request',
        description: 'User requested access to personal data from Rights Center.',
        metadata: {
          asset_id: assetId,
          source: 'Rights Center',
        },
      }),
    });
  }

  async createDeletionRequest(userId: string, assetId?: string): Promise<void> {
    await this.requestApi('/api/v1/rights-requests/deletion-request', {
      method: 'POST',
      body: JSON.stringify({
        user_id: userId,
        status: 'pending',
        reason: 'User requested data deletion from Rights Center',
        metadata: {
          asset_id: assetId,
          requested_at: new Date().toISOString(),
          source: 'Rights Center',
        },
      }),
    });
  }

  // Consent endpoints
  async getUserConsents(userId: string, assetId?: string): Promise<ConsentGroup[]> {
    const normalizeArrayResponse = (payload: any): any[] => {
      if (Array.isArray(payload)) return payload;
      if (Array.isArray(payload?.data)) return payload.data;
      return [];
    };

    const normalizeStatus = (val: any): 'accepted' | 'declined' => {
      if (val === true || val === 'accepted' || val === 'approved') return 'accepted';
      if (val === false || val === 'declined' || val === 'rejected') return 'declined';
      if (typeof val === 'string') {
        const v = val.toLowerCase();
        if (v === 'accepted' || v === 'approved' || v === 'yes' || v === 'true') return 'accepted';
        if (v === 'declined' || v === 'rejected' || v === 'no' || v === 'false') return 'declined';
      }
      return 'declined';
    };

    const firstDefined = (...values: any[]) =>
      values.find((v) => v !== undefined && v !== null && String(v) !== '');

    const assetQuery = assetId ? `?asset_id=${encodeURIComponent(assetId)}` : '';
    const userPath = `/api/v1/banners/user/${encodeURIComponent(userId)}${assetQuery}`;
    const allPath = `/api/v1/banners${assetQuery}`;

    const userRows = normalizeArrayResponse(await this.requestApi<any>(userPath));
    const sourceRows = userRows.length > 0 ? userRows : normalizeArrayResponse(await this.requestApi<any>(allPath));

    let merged: ConsentGroup[] = sourceRows.map((cp: any) => {
      const cpId = String(cp?.collection_point || cp?.id || '');
      const shown_to_principal = !!cp?.shown_to_principal;
      const purposes: Purpose[] = (cp?.purposes || []).map((p: any) => ({
        ...p,
        id: String(p?.id ?? ''),
        name: String(p?.name ?? p?.title ?? ''),
        description: String(p?.description ?? ''),
        expiry_period: String(p?.expiry_period ?? p?.expiry_type ?? p?.expiry ?? ''),
        is_mandatory: Boolean(p?.is_mandatory),
        consented: normalizeStatus(p?.consented),
      }));

      return {
        ...cp,
        collection_point: cpId,
        title: String(cp?.title ?? cp?.name ?? 'Collection Point'),
        shown_to_principal,
        purposes,
      } as ConsentGroup;
    });

    // If assetId was provided, keep only matching collection points (web behavior).
    if (assetId) {
      merged = merged.filter((cp: any) => {
        const cpAssetId = firstDefined(cp?.asset?.id, cp?.asset_id, cp?.assetId, '');
        return String(cpAssetId) === String(assetId);
      });
    }

    return merged;
  }

  async getAllBanners(assetId?: string): Promise<ConsentGroup[]> {
    const normalizeArrayResponse = (payload: any): any[] => {
      if (Array.isArray(payload)) return payload;
      if (Array.isArray(payload?.data)) return payload.data;
      return [];
    };

    const normalizeStatus = (val: any): 'accepted' | 'declined' => {
      if (val === true || val === 'accepted' || val === 'approved') return 'accepted';
      if (val === false || val === 'declined' || val === 'rejected') return 'declined';
      if (typeof val === 'string') {
        const v = val.toLowerCase();
        if (v === 'accepted' || v === 'approved' || v === 'yes' || v === 'true') return 'accepted';
        if (v === 'declined' || v === 'rejected' || v === 'no' || v === 'false') return 'declined';
      }
      return 'declined';
    };

    const assetQuery = assetId ? `?asset_id=${encodeURIComponent(assetId)}` : '';
    const sourceRows = normalizeArrayResponse(await this.requestApi<any>(`/api/v1/banners${assetQuery}`));

    return sourceRows.map((cp: any) => {
      const cpId = String(cp?.collection_point || cp?.id || '');
      const purposes: Purpose[] = (cp?.purposes || []).map((p: any) => ({
        ...p,
        id: String(p?.id ?? ''),
        name: String(p?.name ?? p?.title ?? ''),
        description: String(p?.description ?? ''),
        expiry_period: String(p?.expiry_period ?? p?.expiry_type ?? p?.expiry ?? ''),
        is_mandatory: Boolean(p?.is_mandatory),
        consented: normalizeStatus(p?.consented),
      }));

      return {
        ...cp,
        collection_point: cpId,
        title: String(cp?.title ?? cp?.name ?? 'Collection Point'),
        shown_to_principal: !!cp?.shown_to_principal,
        purposes,
      } as ConsentGroup;
    });
  }

  /**
   * Fetch all collection points by their individual IDs
   * This is a fallback when the root endpoint doesn't work
   */
  private async fetchAllCollectionPointsByID(): Promise<ConsentGroup[]> {
    // Known collection point IDs (CP002-CP014 based on system configuration)
    const collectionPointIds = [
      'CP002', // Expense Tracker
      'CP003', // KYC Document Upload Form
      'CP004', // Marketing Consent Banner
      'CP006', // Account Dashboard
      'CP007', // Signup Page
      'CP008', // Credit Card Application Form
      'CP009', // Fixed Deposit Page
      'CP010', // Mutual Funds Investment Section
      'CP011', // Digital Gold Investment Interface
      'CP012', // Loan Application Page
      'CP013', // Demat Account Creation
      'CP014', // Federal Bank Account Opening Form
    ];

    console.log('[RightsCenterApi] Fetching', collectionPointIds.length, 'collection points individually...');
    
    const results = await Promise.allSettled(
      collectionPointIds.map(async (cpId) => {
        try {
          // Fetch individual collection point - returns a single ConsentGroup object
          const response = await this.request<ConsentGroup | ConsentGroup[]>(`/${encodeURIComponent(cpId)}`);
          // Handle both single object and array responses
          if (Array.isArray(response)) {
            return response.length > 0 ? response[0] : null;
          }
          return response as ConsentGroup;
        } catch (err: any) {
          // If a specific collection point doesn't exist or fails, skip it silently
          // Don't log as error since some collection points may not exist
          if (!err.message || !err.message.includes('404')) {
            console.warn(`[RightsCenterApi] Collection point ${cpId} fetch failed, skipping:`, err.message?.substring(0, 100));
          }
          return null;
        }
      })
    );

    const banners = results
      .filter((result): result is PromiseFulfilledResult<ConsentGroup> => 
        result.status === 'fulfilled' && result.value !== null
      )
      .map(result => result.value);

    console.log('[RightsCenterApi] Successfully fetched', banners.length, 'collection points');
    return banners;
  }

  async saveConsent(
    collectionId: string,
    payload: ConsentPayload
  ): Promise<void> {
    await this.requestApi(
      `/api/v1/consent/${encodeURIComponent(collectionId)}/consent`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  }

  // DPO endpoint
  async getDPOInfo(): Promise<DPOInfo> {
    return this.requestApi<DPOInfo>('/api/v1/dpo');
  }

  // Nominee endpoints
  async getNominees(userId: string): Promise<Nominee[]> {
    return this.requestApi<Nominee[]>(
      `/api/v1/nominee/user/${encodeURIComponent(userId)}`
    );
  }

  async createNominee(nominee: Nominee): Promise<Nominee> {
    return this.requestApi<Nominee>('/api/v1/nominee', {
      method: 'POST',
      body: JSON.stringify(nominee),
    });
  }

  async updateNominee(id: string, nominee: Nominee): Promise<Nominee> {
    return this.requestApi<Nominee>(`/api/v1/nominee/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(nominee),
    });
  }

  async deleteNominee(id: string): Promise<void> {
    await this.requestApi(`/api/v1/nominee/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
  }

  // Grievance endpoints
  async getGrievanceTickets(userId: string): Promise<GrievanceTicket[]> {
    return this.requestApi<GrievanceTicket[]>(
      `/api/v1/grievance/user/${encodeURIComponent(userId)}`
    );
  }

  async createGrievanceTicket(
    ticket: GrievanceTicket
  ): Promise<GrievanceTicket> {
    return this.requestApi<GrievanceTicket>('/api/v1/grievance', {
      method: 'POST',
      body: JSON.stringify(ticket),
    });
  }
}

export default RightsCenterApi;

