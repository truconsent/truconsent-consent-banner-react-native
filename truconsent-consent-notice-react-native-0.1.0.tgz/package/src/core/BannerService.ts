/**
 * BannerService - HTTP client for banner API calls in React Native
 */
import { Banner } from './types';

export interface FetchBannerConfig {
  bannerId: string;
  apiKey?: string;
  organizationId: string;
  /**
   * Web SDK parity:
   * If provided, use `/api/v1/banners` and include `userId` as query param.
   */
  apiUrl?: string;
  assetId?: string;
  userId?: string;
  token?: string;
  authToken?: string;
}

export interface SubmitConsentConfig {
  collectionPointId: string;
  userId: string;
  purposes: any[];
  action: string;
  apiKey?: string;
  organizationId: string;
  requestId?: string;
  /**
   * Web SDK parity:
   * If provided, use `/api/v1/consent/{collectionPointId}/consent`.
   */
  apiUrl?: string;
  assetId?: string;
  token?: string;
  authToken?: string;
  metadata?: Record<string, any>;
}

function withNoTrailingSlash(url: string) {
  return url.replace(/\/$/, '');
}

/**
 * Fetch banner configuration from API
 */
export async function fetchBanner(config: FetchBannerConfig): Promise<Banner> {
  const {
    bannerId,
    apiKey,
    organizationId,
    apiUrl,
    assetId,
    userId,
    token,
    authToken,
  } = config;

  if (!bannerId) {
    throw new Error('Missing bannerId');
  }
  if (!organizationId) {
    throw new Error('Missing organizationId - Organization ID is required for authentication');
  }

  const effectiveToken = token ?? authToken;
  if (!apiKey && !effectiveToken) {
    throw new Error('Missing apiKey/token - authentication is required');
  }

  if (!apiUrl) {
    throw new Error('Missing apiUrl - TruAPI root URL is required');
  }

  const base = `${withNoTrailingSlash(apiUrl)}/api/v1/banners`;
  const encodedBannerId = encodeURIComponent(bannerId);
  const encodedAssetId = assetId ? encodeURIComponent(assetId) : '';

  let url = assetId
    ? `${base}/${encodedAssetId}/${encodedBannerId}`
    : `${base}/${encodedBannerId}`;
  if (userId) {
    url = `${url}?userId=${encodeURIComponent(userId)}`;
  }

  console.log('Fetching banner from:', url);
  
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(apiKey ? { 'X-API-Key': apiKey } : {}),
      ...(effectiveToken ? { Authorization: `Bearer ${effectiveToken}` } : {}),
      'X-Org-Id': organizationId,
    },
  });

  console.log('Banner API response status:', response.status);

  if (response.status === 401) {
    throw new Error('Authentication required - Invalid or missing API key');
  }
  if (response.status === 403) {
    throw new Error('Access forbidden - API key does not have permission to access this banner');
  }
  if (response.status === 404) {
    throw new Error(`Banner not found - Banner ID "${bannerId}" does not exist or is not accessible`);
  }
  if (!response.ok) {
    let errorMessage = `Failed to load banner (${response.status})`;
    try {
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const errorData = await response.json();
        errorMessage = errorData.message || errorData.error || errorMessage;
      } else {
        const errorText = await response.text();
        // Try to extract meaningful error from HTML response
        const match = errorText.match(/<p>(.*?)<\/p>/i);
        if (match && match[1]) {
          errorMessage = match[1].trim();
        } else if (errorText && errorText.length < 200) {
          errorMessage = errorText;
        }
      }
    } catch (e) {
      console.error('Error parsing error response:', e);
    }
    console.error('Banner API error:', errorMessage);
    throw new Error(errorMessage);
  }

  const data = await response.json();
  console.log('Banner data received:', JSON.stringify(data, null, 2));
  return data;
}

/**
 * Submit consent to the backend
 */
export async function submitConsent(config: SubmitConsentConfig): Promise<any> {
  const {
    collectionPointId,
    userId,
    purposes,
    action,
    apiKey,
    organizationId,
    requestId,
    apiUrl,
    assetId,
    token,
    authToken,
    metadata,
  } = config;

  if (!collectionPointId) {
    throw new Error('Missing collectionPointId');
  }
  if (!organizationId) {
    throw new Error('Missing organizationId');
  }

  const effectiveToken = token ?? authToken;
  if (!apiKey && !effectiveToken) {
    throw new Error('Missing apiKey/token - authentication is required');
  }

  if (!apiUrl) {
    throw new Error('Missing apiUrl - TruAPI root URL is required');
  }

  const url = `${withNoTrailingSlash(apiUrl)}/api/v1/consent/${encodeURIComponent(collectionPointId)}/consent`;

  const payload: Record<string, any> = {
    userId,
    purposes,
    action,
  };
  if (requestId) payload.requestId = requestId;
  if (metadata) payload.metadata = metadata;
  if (assetId) payload.assetId = assetId;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(apiKey ? { 'X-API-Key': apiKey } : {}),
      ...(effectiveToken ? { Authorization: `Bearer ${effectiveToken}` } : {}),
      'X-Org-Id': organizationId,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error('Failed to submit consent');
  }

  return response.json();
}

